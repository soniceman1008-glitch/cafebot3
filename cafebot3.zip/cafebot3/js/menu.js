// menu.js — CafeBot3 menu & business data
// Edit this file to customize the cafe's name, hours, location and menu.

const CAFE_INFO = {
  name: "Cafe Aroma",
  tagline: "Freshly brewed, freshly baked.",
  hours: {
    "Mon-Fri": "7:00 AM - 8:00 PM",
    "Sat-Sun": "8:00 AM - 9:00 PM"
  },
  location: "123 Main Street, Downtown",
  phone: "+1 (555) 123-4567",
  wifi: {
    network: "CafeAroma-Guest",
    password: "coffeeholic"
  }
};

const MENU = [
  { id: "esp01", category: "Coffee", name: "Espresso", price: 2.5, desc: "Rich double shot of espresso." },
  { id: "lat01", category: "Coffee", name: "Latte", price: 3.75, desc: "Espresso with steamed milk." },
  { id: "cap01", category: "Coffee", name: "Cappuccino", price: 3.75, desc: "Espresso, steamed milk, thick foam." },
  { id: "mch01", category: "Coffee", name: "Mocha", price: 4.25, desc: "Espresso, chocolate, steamed milk." },
  { id: "cld01", category: "Coffee", name: "Cold Brew", price: 4.0, desc: "Slow-steeped, smooth and bold." },
  { id: "tea01", category: "Tea", name: "Green Tea", price: 2.75, desc: "Light and refreshing." },
  { id: "tea02", category: "Tea", name: "Chai Latte", price: 3.5, desc: "Spiced tea with steamed milk." },
  { id: "pas01", category: "Pastries", name: "Croissant", price: 3.0, desc: "Buttery, flaky, baked fresh daily." },
  { id: "pas02", category: "Pastries", name: "Blueberry Muffin", price: 3.25, desc: "Loaded with real blueberries." },
  { id: "pas03", category: "Pastries", name: "Chocolate Brownie", price: 3.5, desc: "Fudgy and rich." },
  { id: "san01", category: "Sandwiches", name: "Turkey & Swiss", price: 6.5, desc: "On toasted sourdough." },
  { id: "san02", category: "Sandwiches", name: "Veggie Panini", price: 6.0, desc: "Grilled vegetables and mozzarella." }
];

// Expose to other scripts
window.CAFE_INFO = CAFE_INFO;
window.MENU = MENU;
