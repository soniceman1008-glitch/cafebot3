// app.js — wires the CafeBot engine to the chat UI

document.addEventListener("DOMContentLoaded", () => {
  const log = document.getElementById("chat-log");
  const form = document.getElementById("chat-form");
  const input = document.getElementById("chat-input");
  const cafeNameEls = document.querySelectorAll("[data-cafe-name]");
  const cafeTaglineEls = document.querySelectorAll("[data-cafe-tagline]");

  cafeNameEls.forEach((el) => (el.textContent = CAFE_INFO.name));
  cafeTaglineEls.forEach((el) => (el.textContent = CAFE_INFO.tagline));

  function appendMessage(text, sender) {
    const bubble = document.createElement("div");
    bubble.className = `msg ${sender}`;
    bubble.innerText = text;
    log.appendChild(bubble);
    log.scrollTop = log.scrollHeight;
    return bubble;
  }

  function botReply(text) {
    // tiny "typing" delay for a more natural feel
    const typing = appendMessage("...", "bot typing");
    setTimeout(() => {
      typing.remove();
      appendMessage(text, "bot");
    }, 300 + Math.random() * 300);
  }

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const text = input.value;
    if (!text.trim()) return;
    appendMessage(text, "user");
    input.value = "";
    const reply = CafeBot.respond(text);
    botReply(reply);
  });

  // Quick-action chips
  document.querySelectorAll(".chip").forEach((chip) => {
    chip.addEventListener("click", () => {
      const text = chip.dataset.chip;
      appendMessage(text, "user");
      const reply = CafeBot.respond(text);
      botReply(reply);
    });
  });

  // Greet on load
  botReply(CafeBot.respond("hello"));
});
