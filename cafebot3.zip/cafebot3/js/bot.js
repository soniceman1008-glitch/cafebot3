// bot.js — CafeBot3 conversation engine
// A lightweight, dependency-free rule/keyword based chatbot.
// No external API key required. Swap `respond()` internals to call a real
// LLM API later if you want smarter answers — the UI layer doesn't change.

const CafeBot = (function () {
  const cart = []; // { id, name, price, qty }

  function money(n) {
    return "$" + n.toFixed(2);
  }

  function findMenuItem(text) {
    const t = text.toLowerCase();
    return MENU.find(
      (item) =>
        t.includes(item.name.toLowerCase()) ||
        t.includes(item.id.toLowerCase())
    );
  }

  function categoryList() {
    const cats = [...new Set(MENU.map((m) => m.category))];
    return cats.join(", ");
  }

  function menuByCategory(category) {
    const items = MENU.filter(
      (m) => m.category.toLowerCase() === category.toLowerCase()
    );
    if (!items.length) return null;
    return items.map((m) => `• ${m.name} — ${money(m.price)}`).join("\n");
  }

  function fullMenuText() {
    const cats = [...new Set(MENU.map((m) => m.category))];
    return cats
      .map((c) => `**${c}**\n${menuByCategory(c)}`)
      .join("\n\n");
  }

  function cartText() {
    if (!cart.length) return "Your cart is empty.";
    const lines = cart.map(
      (c) => `${c.qty} x ${c.name} — ${money(c.price * c.qty)}`
    );
    const total = cart.reduce((sum, c) => sum + c.price * c.qty, 0);
    return lines.join("\n") + `\n\nTotal: ${money(total)}`;
  }

  function addToCart(item, qty) {
    const existing = cart.find((c) => c.id === item.id);
    if (existing) {
      existing.qty += qty;
    } else {
      cart.push({ id: item.id, name: item.name, price: item.price, qty });
    }
  }

  function extractQty(text) {
    const match = text.match(/(\d+)\s*x?/i);
    if (match) {
      const n = parseInt(match[1], 10);
      if (n > 0 && n < 50) return n;
    }
    return 1;
  }

  // Very small intent classifier based on keyword matching.
  function classify(text) {
    const t = text.toLowerCase().trim();

    if (/^(hi|hello|hey|salam|assalam)/.test(t)) return "greeting";
    if (/(help|what can you do|options|commands)/.test(t)) return "help";
    if (/(hour|open|close|timing)/.test(t)) return "hours";
    if (/(where|location|address|directions)/.test(t)) return "location";
    if (/(wifi|wi-fi|password|internet)/.test(t)) return "wifi";
    if (/(phone|call|contact|number)/.test(t)) return "contact";
    if (/(menu|what do you have|what's on offer|items)/.test(t)) return "menu";
    if (/(cart|order summary|my order|review order)/.test(t)) return "cart";
    if (/(checkout|place order|confirm order|submit order)/.test(t))
      return "checkout";
    if (/(clear cart|empty cart|start over|cancel order)/.test(t))
      return "clear_cart";
    if (/(add|order|get me|i want|i'll have|i would like)/.test(t) && findMenuItem(t))
      return "add_item";
    if (findMenuItem(t)) return "item_info";
    if (/(thank|thanks|shukriya)/.test(t)) return "thanks";
    if (/(bye|goodbye|see you)/.test(t)) return "goodbye";

    return "fallback";
  }

  function respond(rawText) {
    const text = rawText.trim();
    if (!text) return "Say something and I'll do my best to help!";

    const intent = classify(text);

    switch (intent) {
      case "greeting":
        return `Hi there! Welcome to ${CAFE_INFO.name} 👋 ${CAFE_INFO.tagline}\nAsk me about our menu, hours, location, or say "order [item]" to start an order.`;

      case "help":
        return [
          "Here's what I can help with:",
          "• \"menu\" — see everything we offer",
          "• \"order [item]\" — add something to your cart (e.g. \"order 2 lattes\")",
          "• \"cart\" — review your order",
          "• \"checkout\" — place your order",
          "• \"hours\", \"location\", \"wifi\", \"contact\" — cafe info",
        ].join("\n");

      case "hours":
        return `Our hours:\n${Object.entries(CAFE_INFO.hours)
          .map(([d, h]) => `${d}: ${h}`)
          .join("\n")}`;

      case "location":
        return `You can find us at ${CAFE_INFO.location}.`;

      case "wifi":
        return `Wi-Fi network: ${CAFE_INFO.wifi.network}\nPassword: ${CAFE_INFO.wifi.password}`;

      case "contact":
        return `You can reach us at ${CAFE_INFO.phone}.`;

      case "menu":
        return `Here's our menu (categories: ${categoryList()}):\n\n${fullMenuText()}`;

      case "item_info": {
        const item = findMenuItem(text);
        return `${item.name} — ${money(item.price)}\n${item.desc}\nSay "order ${item.name}" to add it to your cart.`;
      }

      case "add_item": {
        const item = findMenuItem(text);
        const qty = extractQty(text);
        addToCart(item, qty);
        return `Added ${qty} x ${item.name} to your cart.\n\n${cartText()}`;
      }

      case "cart":
        return cartText();

      case "clear_cart":
        cart.length = 0;
        return "Your cart has been cleared.";

      case "checkout": {
        if (!cart.length) return "Your cart is empty — add something first!";
        const summary = cartText();
        cart.length = 0;
        return `Order placed! Here's your receipt:\n\n${summary}\n\nThank you for choosing ${CAFE_INFO.name}! We'll have it ready shortly.`;
      }

      case "thanks":
        return "You're very welcome! Anything else I can get for you?";

      case "goodbye":
        return `Thanks for stopping by ${CAFE_INFO.name}! See you soon ☕`;

      default:
        return `I didn't quite catch that. Try "menu", "hours", "order [item]", or "help" to see what I can do.`;
    }
  }

  return { respond, getCart: () => cart.slice() };
})();

window.CafeBot = CafeBot;
