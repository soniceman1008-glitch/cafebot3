# cafebot3

A lightweight, dependency-free chat assistant for a cafe website. Answers questions about the menu, hours, location, and Wi-Fi, and lets visitors build a simple order in a chat interface — no backend, no API keys, no build step.

## Features

- Rule-based conversation engine (`js/bot.js`) — fast, free, works offline
- Editable menu & cafe info in one file (`js/menu.js`)
- Simple cart: "order 2 lattes", "cart", "checkout", "clear cart"
- Quick-reply chips for common questions
- Clean, mobile-friendly chat UI

## Quick start

No build tools needed. Just open `index.html` in a browser, or serve the folder:

```bash
python3 -m http.server 8000
# then visit http://localhost:8000
```

## Customize

Edit `js/menu.js`:

- `CAFE_INFO` — name, tagline, hours, address, phone, Wi-Fi
- `MENU` — array of `{ id, category, name, price, desc }`

No other file needs to change to update the menu or cafe details.

## Try it

Type things like:

- `menu`
- `order 2 lattes`
- `cart`
- `checkout`
- `hours`
- `wifi`

## Roadmap ideas

- Swap the rule-based engine in `bot.js` for a real LLM API call for smarter, open-ended answers
- Add a backend (Node/Express) to persist orders and connect to a kitchen dashboard
- Add payment integration (Stripe) at checkout
- Deploy free via GitHub Pages

## Deploying to GitHub Pages

1. Push this repo to GitHub (already done if you're reading this from the repo).
2. Go to **Settings → Pages**.
3. Under "Build and deployment", choose **Deploy from a branch**, branch `main`, folder `/ (root)`.
4. Your bot will be live at `https://<your-username>.github.io/cafebot3/`.
